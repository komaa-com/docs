# Teams app manifest — StandIn example

Public **example** [Microsoft Teams app package](https://learn.microsoft.com/en-us/microsoftteams/platform/resources/schema/manifest-schema) for [StandIn](https://standin.komaa.com): voice, video, and a lip-synced avatar in Teams using your own Azure bot and the Teams Voice Plugin (OpenClaw or Hermes Agent).

This folder contains **no secrets** — only placeholder GUIDs and product copy. Replace the placeholders before you build your `.zip` and install the app.

---

## Quick start

1. **Replace the three placeholder GUIDs** in `manifest.json` (see [Placeholders](#placeholders)).
2. **Set `validDomains`** to the hostname StandIn gives you in your dashboard (often `standin.komaa.com`).
3. **Add icons** to this folder:
   - `color.png` — 192×192 px, full-color app icon
   - `outline.png` — 32×32 px, transparent background
4. **Create the package:** zip `manifest.json`, `color.png`, and `outline.png` (files at the root of the zip, not in a subfolder).
5. **Upload** the zip in Teams Admin Center (org catalog) or sideload for testing.
6. **Azure Bot** (same Entra app as `botId`):
   - Teams channel → **calling webhook** → URL from your StandIn dashboard
   - Configuration → **messaging endpoint** → URL from your StandIn dashboard
   - Admin-consent Graph **application** permissions (see [Graph permissions](#graph-permissions)).
7. **StandIn dashboard:** register your plugin WebSocket URL and matching HMAC `sharedSecret`.

Product documentation: [standin.komaa.com](https://standin.komaa.com)

---

## Placeholders

The example manifest uses obvious placeholders. **Do not publish with these values.**

| Field | Placeholder in example | You replace with |
|-------|------------------------|------------------|
| `id` | `00000000-0000-0000-0000-000000000000` | A **new random GUID** for this Teams app package (unique per app listing; not the bot ID). |
| `bots[].botId` | `11111111-1111-1111-1111-111111111111` | Your **Microsoft Entra application (client) ID** — the same ID as the Azure Bot resource (`MicrosoftAppId`). |
| `webApplicationInfo.id` | Same as `botId` | **Must match `botId`** for a standard single-app bot. |
| `validDomains` | `[]` (empty) | At least the **StandIn host** from your dashboard, e.g. `["standin.komaa.com"]`. |

Generate GUIDs with [uuidgenerator.net](https://www.uuidgenerator.net/) or `uuidgen` / `[guid]::NewGuid()` on Windows.

---

## Field reference

| Field | What it is |
|-------|------------|
| `$schema` | JSON Schema URL for validating the manifest in App Studio or CI. |
| `manifestVersion` | Teams manifest schema version (must match `$schema`). |
| `version` | Semver for **your app package**; bump when you republish the zip. |
| `id` | Teams **app package** ID (catalog / sideload identity). Not the Azure bot ID. |
| `name.short` | App name in Teams (≤ 30 characters). |
| `name.full` | Full name in admin views (≤ 100 characters). |
| `developer.name` | Publisher shown to admins who install the app. |
| `developer.websiteUrl` | Product home page. |
| `developer.privacyUrl` | Privacy policy URL (required for admin / store review). |
| `developer.termsOfUseUrl` | Terms of use URL (required for admin / store review). |
| `description.short` | One-line install blurb (≤ 80 characters). |
| `description.full` | Long description for Teams Admin Center (≤ 4000 characters). |
| `icons.color` | Filename of the 192×192 color icon inside the zip. |
| `icons.outline` | Filename of the 32×32 outline icon inside the zip. |
| `accentColor` | Hex accent color for Teams UI chrome. |
| `bots[].botId` | **Entra app (client) ID** for your Azure Bot — how Teams links the installed app to your bot. Public identifier, not a secret. |
| `bots[].scopes` | Install surfaces: `personal` (1:1), `team`, `groupChat`. |
| `bots[].isNotificationOnly` | `false` for an interactive bot (chat + calls). |
| `bots[].supportsCalling` | `true` — **required** for Teams voice calls. |
| `bots[].supportsVideo` | `true` — **required** for video / CVI avatar tile. |
| `bots[].supportsFiles` | `true` — file cards (e.g. meeting minutes attachments). |
| `validDomains` | Hostnames Teams trusts for this app (include StandIn’s endpoint host). |
| `webApplicationInfo.id` | Same Entra app ID as `botId` (SSO / token context in Teams). |
| `authorization.permissions.resourceSpecific` | **Resource-specific consent (RSC)** — read/send messages and read team membership **only in teams where the app is installed**. Works alongside tenant-wide Graph application permissions on the Entra app. |

---

## Graph permissions

Configure these as **application** permissions on the **same Entra app** as `botId`, then admin-consent in your tenant. Full list and setup: [StandIn docs — Architecture](https://standin.komaa.com).

| Permission | Purpose |
|------------|---------|
| `Calls.JoinGroupCall.All` | Answer and join Teams calls and meetings |
| `Calls.AccessMedia.All` | Real-time call audio and video media |
| `Calls.InitiateGroupCall.All` | Outbound “call me back” (optional if unused) |
| `Chat.Read.All` | Chat / thread context |
| `ChatMessage.Read.Chat` | Read messages in chats the bot is in |
| `Sites.ReadWrite.All` | SharePoint / OneDrive file cards for meeting minutes (optional) |

RSC entries in the manifest (channel read/send, member read, etc.) are consented **per team** when the app is installed — they do not replace the application permissions above.

---

## Package layout

**Source folder** (this repo — for editing):

```
msteams/
  manifest.json
  color.png
  outline.png
  README.md          ← documentation only; not part of the upload
```

**Teams app package to upload** — a `.zip` whose **root contains the three files directly** (no parent folder inside the zip):

```
msteams.zip
├── manifest.json    ← at the zip root
├── color.png        ← at the zip root
└── outline.png      ← at the zip root
```

> **Important:** Teams rejects packages where files sit inside a subfolder (e.g. `msteams/manifest.json`). Select `manifest.json`, `color.png`, and `outline.png` and zip **those files only**, or zip from inside the folder so the archive root is the three files themselves.

---

## Architecture (how the pieces connect)

```
Your agent (OpenClaw / Hermes)
        ↕
Teams Voice Plugin  ← WebSocket server on your machine
        ↕ HMAC WebSocket
StandIn (hosted)    ← joins Teams call, renders avatar, forwards media
        ↕
Microsoft Teams
```

The manifest defines how **Teams** recognizes and installs your **bot identity** (`botId`). StandIn and your plugin handle calling, media, and AI dialogue — configured outside this file.

---

## License & use

This example manifest is provided as-is for integrators building on StandIn. Customize names, descriptions, icons, and GUIDs for your own bot and tenant before publishing.
